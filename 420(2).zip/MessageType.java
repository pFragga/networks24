public enum MessageType {
	REGISTER,
	LOGIN,
	LOGOUT,
	LIST,
	DETAILS,
	INFORM,
	ACTIVE,
	NOTIFY,
	DOWNLOAD,
	GENERIC;
}
